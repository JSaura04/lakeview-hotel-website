// userService.js
import bcrypt from "bcryptjs";
import {
  doc,
  getDoc,
  increment,
  serverTimestamp,
  setDoc,
  updateDoc,
} from "firebase/firestore";
import { db } from "./init";

type CreateUserInput = {
  name: string;
  email: string;
  password: string;
  phoneNumber: string;
};

/**
 * Gets the next user ID from the "users" counter document.
 */
async function getNextUserId() {
  const counterRef = doc(db, "counters", "users");

  const counterSnap = await getDoc(counterRef);
  if (!counterSnap.exists()) {
    await setDoc(counterRef, { value: 1 });
    return 1;
  } else {
    const currentValue = counterSnap.data().value;
    await updateDoc(counterRef, { value: increment(1) });
    return currentValue + 1;
  }
}

/**
 * Creates a new user in the database.
 */
export async function createUser({
  name,
  email,
  password,
  phoneNumber,
}: CreateUserInput): Promise<number | void> {
  try {
    const id = await getNextUserId();
    const hashedPassword = await bcrypt.hash(password, 10);

    await setDoc(doc(db, "users", id.toString()), {
      id,
      name,
      email,
      phoneNumber,
      password: hashedPassword,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      deletedAt: null,
    });

    console.log(`✅ Usuario creado con ID ${id}`);
    return id;
  } catch (error) {
    console.error("❌ Error al crear el usuario:", error);
  }
}
