// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDUBds2eJ4wlbg7O4WFs6QKuiXWbagmJPE",
  authDomain: "lakeview-hotel.firebaseapp.com",
  projectId: "lakeview-hotel",
  storageBucket: "lakeview-hotel.firebasestorage.app",
  messagingSenderId: "623050212884",
  appId: "1:623050212884:web:25745fcecd35b928144901",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Inicializa Firestore
const db = getFirestore(app);

export { app, db };
