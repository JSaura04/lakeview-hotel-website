import { FC } from "react";

interface NavlinkProps {
  href: string;
  label: string;
}

/**
 * A primitive component for creating a navigation link.
 *
 * @param {string} href - The href attribute of the link.
 * @param {string} label - The label of the link.
 *
 * @returns {React.ReactElement} - A React element representing the navigation link.
 */

const NavLink: FC<NavlinkProps> = ({ href, label }) => {
  return (
    <li>
      <a
        href={href}
        className="hover:text-indigo-400 transition-colors duration-200"
      >
        {label}
      </a>
    </li>
  );
};
export { NavLink };
