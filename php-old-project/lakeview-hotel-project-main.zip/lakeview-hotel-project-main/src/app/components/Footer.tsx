"use client";

import { useTranslations } from "next-intl";
import Image from "next/image";
import { FC } from "react";
import { NavLink } from "./primitives/Navlink";

/**
 * Footer component that displays the footer of the website.
 */

const Footer: FC = () => {
  const t = useTranslations("");
  return (
    <footer className="w-full bg-black text-white py-12 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between gap-10">
        <div className="flex-1">
          <Image src="/imgs/LogoText.png" alt="Logo" width={400} height={500} />
          <p className="text-gray-300">{t("footer.description")}</p>
        </div>

        <div className="flex-1">
          <ul className="space-y-2">
            <NavLink href="/" label={t("links.home")} />
            <NavLink href="/" label={t("links.services")} />
            <NavLink href="/" label={t("links.reviews")} />
          </ul>
        </div>
      </div>

      <div className="mt-10 border-t border-gray-700 pt-6 text-center text-gray-400 text-sm">
        &copy; {new Date().getFullYear()} {t("footer.copyright")}
      </div>
    </footer>
  );
};

export default Footer;
