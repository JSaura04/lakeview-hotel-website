"use client";

import Button from "@mui/material/Button";
import { LogIn } from "lucide-react";
import React from "react";

type Props = {
  onClick?: () => void;
  className?: string;
};

const LoginButton: React.FC<Props> = ({ onClick, className = "" }) => {
  return (
    <Button
      onClick={onClick}
      aria-label="Iniciar sesión"
      disableElevation
      className={`
        group relative inline-flex items-center justify-start h-10 rounded-md
        bg-slate-900 text-white border border-white/10 shadow-sm overflow-hidden
        normal-case min-w-0 px-0 transition-all duration-200 ease-in-out
        w-10 hover:w-36 focus:w-36 focus:outline-none focus:ring-2
        focus:ring-indigo-500 focus:ring-offset-2
        ${className}
      `}
    >
      <span className="flex-shrink-0 ml-2 transition-transform duration-200 ease-in-out group-hover:translate-x-1">
        <LogIn size={18} />
      </span>

      <span
        className="
          absolute left-12 opacity-0 whitespace-nowrap
          text-sm font-medium tracking-tight
          transition-all duration-200 ease-in-out
          group-hover:opacity-100 group-hover:translate-x-2
        "
        aria-hidden="true"
      >
        Iniciar sesión
      </span>
    </Button>
  );
};

export default LoginButton;
