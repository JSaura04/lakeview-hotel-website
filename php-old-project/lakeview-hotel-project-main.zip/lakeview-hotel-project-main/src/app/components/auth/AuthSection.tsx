import { FC } from "react";
import LoginButton from "./buttons/LoginButton";

export const AuthSection: FC = () => {
  return (
    <div>
      <LoginButton />
    </div>
  );
};
