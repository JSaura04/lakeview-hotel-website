"use client";

import { app } from "@/configs/firebase/init";
import { createUser } from "@/configs/firebase/user";
import {
  createUserWithEmailAndPassword,
  getAuth,
  updateProfile,
} from "firebase/auth";
import { useState } from "react";

export default function RegisterForm() {
  const auth = getAuth(app);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        email,
        password
      );
      await updateProfile(userCredential.user, { displayName: name });
      await createUser({ name, email, password, phoneNumber }); // Guardar en Firestore
      alert("✅ Cuenta creada con éxito");
    } catch (err: unknown) {
      setError("No se pudo registrar el usuario");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      onSubmit={handleRegister}
      className="flex flex-col gap-4 w-full max-w-sm"
    >
      <h2 className="text-2xl font-semibold text-center">Crear cuenta</h2>
      <input
        type="text"
        placeholder="Nombre completo"
        className="border p-2 rounded-md"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
      />
      <input
        type="email"
        placeholder="Correo electrónico"
        className="border p-2 rounded-md"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
      />
      <input
        type="password"
        placeholder="Contraseña"
        className="border p-2 rounded-md"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
      />
      <input
        type="tel"
        placeholder="Número de teléfono"
        className="border p-2 rounded-md"
        value={phoneNumber}
        onChange={(e) => setPhoneNumber(e.target.value)}
      />
      {error && <p className="text-red-500 text-sm text-center">{error}</p>}
      <button
        type="submit"
        className="bg-green-600 text-white py-2 rounded-md hover:bg-green-700 transition"
        disabled={loading}
      >
        {loading ? "Creando cuenta..." : "Registrarse"}
      </button>
    </form>
  );
}
