"use client";

import { Menu, X } from "lucide-react";
import { useTranslations } from "next-intl";
import Image from "next/image";
import { FC, useState } from "react";
import { LanguageSelector } from "./LanguageSelecctor";
import { NavLink } from "./primitives/Navlink";

export const Header: FC = () => {
  const t = useTranslations("links");
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => setIsOpen((prev) => !prev);

  return (
    <header className="bg-black w-full text-white py-6 px-6 relative">
      <div className="flex justify-between items-center pb-7 relative">
        <div className="absolute right-0 sm:mr-10 lg:mr-0 top-1/2 transform -translate-y-1/2">
          <LanguageSelector />
        </div>

        <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
          <Image src="/imgs/LogoText.png" alt="Logo" width={350} height={350} />
        </div>

        <button
          className="md:hidden absolute right-0 top-1/2 transform -translate-y-1/2 text-white"
          onClick={toggleMenu}
          aria-label="Toggle Menu"
        >
          {isOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      <nav className="hidden md:flex flex-col">
        <ul className="flex mt-6 flex-row space-x-4 justify-center">
          <NavLink href="/" label={t("book")} />
          <NavLink href="/" label={t("about")} />
          <NavLink href="/" label={t("services")} />
        </ul>
      </nav>

      {isOpen && (
        <nav className="md:hidden mt-4 bg-black/95 rounded-md shadow-lg p-4 animate-slideDown">
          <ul className="flex flex-col space-y-3">
            <NavLink href="/" label={t("book")} />
            <NavLink href="/" label={t("about")} />
            <NavLink href="/" label={t("services")} />
            <NavLink href="/auth/" label={t("login")} />
          </ul>
        </nav>
      )}
    </header>
  );
};
