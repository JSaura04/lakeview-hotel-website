"use client";

import { useTranslations } from "next-intl";
import Image from "next/image";
import React, { useEffect, useState } from "react";

const images = [
  "/imgs/1.jpeg",
  "/imgs/2.jpg",
  "/imgs/3.png",
  "/imgs/4.jpg",
  "/imgs/5.jpg",
];

/**
 * A carousel component that displays a slideshow of images.
 */
const HomeCarousel: React.FC = () => {
  const [current, setCurrent] = useState(0);
  const t = useTranslations("header");
  const length = images.length;

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % length);
    }, 4000);
    return () => clearInterval(interval);
  }, [length]);

  return (
    <div className="pt-24 md:pt-4 overflow-hidden shadow-2xl">
      <h1 className="text-center text-black text-2xl md:text-3xl font-bold mb-6 t">
        {t("start")}
      </h1>

      <div className="bg-black py-4 md:py-6">
        <div className="relative h-64 sm:h-80 md:h-96 lg:h-[500px] w-full">
          {images.map((img, index) => {
            const isActive = index === current;
            const offset = (index - current) * 100;

            return (
              <div
                key={index}
                className={`
                    absolute top-0 left-0 w-full h-full transition-transform duration-700 ease-in-out
                    ${isActive ? "z-20 opacity-100" : "z-0 opacity-0"}
                    `}
                style={{ transform: `translateX(${offset}%)` }}
              >
                <div className="relative w-full h-full overflow-hidden group bg-black">
                  <Image
                    src={img}
                    alt={`Slide ${index + 1}`}
                    fill
                    className="
                      object-cover w-full h-full
                      transition-transform duration-700 ease-in-out
                      group-hover:scale-105
                    "
                  />
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex justify-center items-center mt-4 md:mt-6 space-x-3">
          {images.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrent(index)}
              className={`w-4 h-4 rounded-full transition-all duration-300 focus:outline-none ${
                index === current
                  ? "bg-white scale-125"
                  : "bg-white/50 scale-100"
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default HomeCarousel;
