import HomeCarousel from "@/src/app/components/home/HomeCarousel";

export const metadata = {
  title: "Lakeview Hotel",
};

export default function Home() {
  return (
    <div>
      <HomeCarousel />
    </div>
  );
}
