import Footer from "@/src/app/components/Footer";
import { Header } from "@/src/app/components/Header";
import { NextIntlClientProvider } from "next-intl";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

type Props = {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
};

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const AVAILABLE_LOCALES = ["en", "es"];

export default async function RootLayout({ children, params }: Props) {
  const { locale } = await params;

  const selectedLocale = AVAILABLE_LOCALES.includes(locale) ? locale : "en";

  let messages;
  try {
    messages = (await import(`../../i18n/${selectedLocale}.json`)).default;
  } catch (e) {
    console.error(
      `No se pudo cargar el archivo de idioma: ${selectedLocale}`,
      e
    );
    messages = {};
  }

  return (
    <html lang={selectedLocale}>
      <NextIntlClientProvider locale={selectedLocale} messages={messages}>
        <body
          className={`${geistSans.variable} ${geistMono.variable} antialiased flex flex-col min-h-screen`}
        >
          <Header />
          <main className="flex-1">{children}</main>
          <Footer />
        </body>
      </NextIntlClientProvider>
    </html>
  );
}
